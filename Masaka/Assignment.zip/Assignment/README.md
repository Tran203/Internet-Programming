# ABC Bank Account
 This web application uses EJBs( <em> Stateful </em> ) to create an interactive web application that allows candidates choose the test they want to write.
 
 ## They can either do an
 - addition
 - subtraction
 - division or 
 - multiplication test.


 > What does the application do?
 - The application generates five (5) random questions for a candidate
 - After a candidate has provided an answer,an outcome gets provided
 - The outcome displays the question asked; the user’s answer; the correct answer; and the actual outcome, that is whether the user got the question right or wrong
 - After all the questions have been asked and answered, a summary report gets generated